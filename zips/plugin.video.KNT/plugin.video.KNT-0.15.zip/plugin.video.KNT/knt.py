# -*- coding: UTF-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import re, os, urllib, urllib2, sys, inspect, cookielib
#import urlresolver
import resolveurl as urlresolver
from lib.airtable import Airtable
import urlparse
import koding
from koding import Add_Dir
                          
from koding import route, Run

	
cookiejar 		= cookielib.CookieJar()
headers 		= [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36')]
addon_handle 	= int(sys.argv[1])
player 			= xbmc.Player()
dialog 			= xbmcgui.Dialog()
addon 			= xbmcaddon.Addon()
icon 			= addon.getAddonInfo('icon')
Fanart 			= ''
path 			= 'KNT'
addon_path 		= addon.getAddonInfo('path')
#icons 			= addon_path + "/resources/icons/"
icons 			= ''











def Get_From_To(text, from_str, to_str, excluding=True):
	if excluding:
		try: r 	= re.search("(?i)"+from_str+"([\S\s]+?)"+to_str,text).group(1)
		except: r = ''
	else:
		try: r 	= re.search("(?i)("+from_str+"[\S\s]+?"+to_str+")",text).group(1)
		except: r = ''
	return r

def Get_Params():
	args	= sys.argv[2]
	if len(args)<=2: return
	text = re.split('[?]',args,1)
	params1	= {}
	params = urlparse.parse_qs(text[1])
	for i in params:
		x = ''.join(params[i])
		params1.update({i:x})
	return params1

def Read_It(url,headers=None,post=None,timeout=60,gzip=False):
	opener 	= urllib2.build_opener(urllib2.HTTPCookieProcessor(cookiejar),urllib2.HTTPBasicAuthHandler(), urllib2.HTTPSHandler(),urllib2.HTTPHandler())
	req     = urllib2.Request(url)
	if headers:
		for h,hv in headers:
			req.add_header(h,hv)
	scr = opener.open(req,post,timeout=timeout).read()
	if gzip :
		import StringIO, gzip
		cmps = StringIO.StringIO(scr)
		ugzp = gzip.GzipFile(fileobj=cmps)
		scr  = ugzp.read()
	return scr

def Play(url,title,thumb):
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	lis	= xbmcgui.ListItem(title,iconImage=thumb,thumbnailImage=thumb)
	lis.setInfo(type='Video', infoLabels ={'Title':title})
	lis.setPath(url)
	player.play(url, lis)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, lis)
	for i in range(0, 120):
		if player.isPlayingVideo(): break
		xbmc.sleep(1000)
	while player.isPlaying():
		xbmc.sleep(2000)
	xbmc.sleep(4000)



params = Get_Params()
mode = None

try: mode = params['mode']
except: pass
try: url = params['url']
except: pass
try: title = params['title']
except: pass
try: thumb = params['iconimage']
except: pass
try: bg = params['fanart']
except: pass
try: desc = params['description']
except: pass



@route("main")
def log():
	Menu()

@route(mode="Menu")
def Menu():

	Add_Dir(name='TEST', url='', mode='', folder=True, icon='', fanart='')
	
	



router.Run()
xbmcplugin.endOfDirectory(addon_handle)
