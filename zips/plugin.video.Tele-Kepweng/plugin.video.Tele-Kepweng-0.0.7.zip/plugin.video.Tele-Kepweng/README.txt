Base Template provided by Salvation Family. Shout out to Mick3yB0y

Notification Code, from tvadd-ons

